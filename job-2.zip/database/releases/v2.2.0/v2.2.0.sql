insert into `settings` (`key`, `value`, `updated_at`, `created_at`) values 

(
    'company_url', 'www.infyom.com', '2020-10-20 00:00:00', '2020-10-20 00:00:00'
)
